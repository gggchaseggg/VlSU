<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title><?php echo $__env->yieldContent('title'); ?></title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
  <div class="container page">
    <?php echo $__env->yieldContent('content'); ?>
  </div>
  <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/labs/lab5/resources/views/layout.blade.php ENDPATH**/ ?>